I wanted to add this code as a demonstration of my first experience using Python.
 I used this project for the simulation of a purchase in a stationery store.

Ena Azcona